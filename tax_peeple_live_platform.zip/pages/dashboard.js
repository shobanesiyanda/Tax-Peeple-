
import Layout from '../components/Layout';
import MetricCard from '../components/MetricCard';

const companies = [
  { name: 'Peeple Logistics (Pty) Ltd', score: 92, status: 'Active' },
  { name: 'Peeple Media (Pty) Ltd', score: 74, status: 'Review needed' },
];

const orders = [
  { id: 'TP-1024', service: 'Company Registration', status: 'Documents Review', progress: '35%' },
  { id: 'TP-1025', service: 'Tax Compliance Status', status: 'Submitted', progress: '75%' },
  { id: 'TP-1026', service: 'Annual Returns', status: 'Completed', progress: '100%' },
];

export default function Dashboard() {
  return (
    <Layout>
      <div className="grid min-h-screen grid-cols-1 lg:grid-cols-[260px_1fr]">
        <aside className="border-r border-white/10 p-5">
          <div className="mb-8">
            <div className="text-xl font-bold">Tax Peeple</div>
            <div className="text-sm text-slate-400">SaaS dashboard</div>
          </div>
          <div className="space-y-2">
            {['Dashboard','Companies','Orders','Documents','Compliance','Billing','Settings'].map(item => (
              <div key={item} className={`rounded-2xl px-4 py-3 text-sm ${item === 'Dashboard' ? 'bg-emerald-400 font-semibold text-slate-950' : 'text-slate-300 border border-white/5'}`}>
                {item}
              </div>
            ))}
          </div>
        </aside>

        <main className="p-6 md:p-8">
          <h1 className="text-3xl font-black">Founder Dashboard</h1>
          <p className="mt-1 text-slate-400">Track compliance, companies, and order status from one interface.</p>

          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            <MetricCard title="Compliance Score" value="83/100" subtitle="Across all tracked companies" />
            <MetricCard title="Companies" value="2" subtitle="Active company profiles" />
            <MetricCard title="Open Orders" value="3" subtitle="In progress this week" />
            <MetricCard title="Alerts" value="2" subtitle="Deadlines need attention" />
          </div>

          <div className="mt-6 grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
            <div className="card p-6">
              <h2 className="text-xl font-bold">Companies</h2>
              <div className="mt-4 space-y-4">
                {companies.map(c => (
                  <div key={c.name} className="rounded-2xl border border-white/10 bg-slate-950 p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold">{c.name}</div>
                        <div className="text-sm text-slate-400">{c.status}</div>
                      </div>
                      <div className="rounded-full bg-emerald-500/15 px-3 py-1 text-sm text-emerald-300">Score {c.score}</div>
                    </div>
                    <div className="mt-4 h-3 rounded-full bg-slate-800">
                      <div className="h-3 rounded-full bg-emerald-400" style={{ width: `${c.score}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card p-6">
              <h2 className="text-xl font-bold">Lead Funnel Snapshot</h2>
              <div className="mt-4 space-y-3">
                {[
                  ['Website visitors', '12,480'],
                  ['Form starts', '1,142'],
                  ['Paid checkouts', '213'],
                  ['Bundle upsells', '71'],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950 px-4 py-3">
                    <span className="text-slate-300">{label}</span>
                    <span className="font-semibold">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="card mt-6 p-6">
            <h2 className="text-xl font-bold">Orders</h2>
            <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
              <div className="grid grid-cols-4 bg-slate-950 p-4 text-sm text-slate-400">
                <div>Order ID</div>
                <div>Service</div>
                <div>Status</div>
                <div>Progress</div>
              </div>
              {orders.map(o => (
                <div key={o.id} className="grid grid-cols-4 border-t border-white/10 p-4 text-sm">
                  <div className="font-medium">{o.id}</div>
                  <div>{o.service}</div>
                  <div>{o.status}</div>
                  <div>{o.progress}</div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </Layout>
  );
}
