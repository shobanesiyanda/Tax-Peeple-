
import Link from 'next/link';
import Layout from '../components/Layout';

const services = [
  ['Company Registration', 'R880'],
  ['Tax Compliance Status', 'R490'],
  ['VAT Registration', 'R950'],
  ['Annual Returns', 'R350'],
  ['Beneficial Ownership', 'R450'],
  ['Tender Ready Pack', 'R6 990'],
];

export default function Home() {
  return (
    <Layout>
      <header className="border-b border-white/10">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div>
            <div className="text-xl font-bold">Tax Peeple</div>
            <div className="text-sm text-slate-400">Compliance infrastructure for SMEs</div>
          </div>
          <div className="flex gap-3">
            <Link className="btn-secondary" href="/dashboard">Dashboard Demo</Link>
            <Link className="btn-primary" href="/funnel">Start Now</Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-16">
        <section className="grid gap-8 md:grid-cols-2">
          <div>
            <div className="mb-4 inline-block rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-2 text-sm text-emerald-300">
              Built for South African founders
            </div>
            <h1 className="text-5xl font-black tracking-tight">Register, manage, and grow your business the compliant way.</h1>
            <p className="mt-5 max-w-xl text-lg text-slate-300">
              Tax Peeple combines a service-led website, a SaaS dashboard, and a lead funnel in one deployable frontend.
            </p>
            <div className="mt-8 flex gap-4">
              <Link className="btn-primary" href="/funnel">Launch Funnel</Link>
              <Link className="btn-secondary" href="/dashboard">View Dashboard</Link>
            </div>
          </div>
          <div className="card p-6">
            <div className="text-sm text-slate-400">Compliance Health</div>
            <div className="mt-2 text-5xl font-black">92/100</div>
            <div className="mt-4 h-3 rounded-full bg-slate-800">
              <div className="h-3 w-[92%] rounded-full bg-emerald-400"></div>
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-slate-950 p-4">
                <div className="text-sm text-slate-400">Pending Orders</div>
                <div className="mt-2 text-2xl font-bold">3</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-slate-950 p-4">
                <div className="text-sm text-slate-400">Next Deadline</div>
                <div className="mt-2 text-lg font-bold">Annual Returns</div>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-16">
          <h2 className="text-3xl font-bold">Services</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {services.map(([title, price]) => (
              <div key={title} className="card p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold">{title}</h3>
                  <span className="text-emerald-300">{price}</span>
                </div>
                <p className="mt-3 text-slate-400">Conversion-focused service card for high-intent founders.</p>
                <Link className="btn-primary mt-5 inline-block" href="/funnel">Select Service</Link>
              </div>
            ))}
          </div>
        </section>
      </main>
    </Layout>
  );
}
