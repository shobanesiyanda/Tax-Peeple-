
import { useState } from 'react';
import Layout from '../components/Layout';

const services = ['Company Registration', 'Tax Compliance Status', 'VAT Registration', 'Annual Returns'];
const packages = ['Starter Compliance Pack', 'Tax Ready Pack', 'Tender Ready Pack'];

export default function Funnel() {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState(services[0]);
  const [pack, setPack] = useState(packages[0]);

  return (
    <Layout>
      <main className="mx-auto max-w-5xl px-6 py-12">
        <h1 className="text-4xl font-black">Lead Funnel</h1>
        <p className="mt-2 text-slate-400">Company Partners-style lead capture, routing, bundle upsell, and checkout summary.</p>

        <div className="mt-6 grid gap-3 md:grid-cols-4">
          {[1,2,3,4].map(n => (
            <div key={n} className={`rounded-2xl border px-4 py-3 text-sm ${step >= n ? 'border-emerald-400 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-slate-900 text-slate-400'}`}>
              Step {n}
            </div>
          ))}
        </div>

        <div className="card mt-6 p-6">
          {step === 1 && (
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h2 className="text-2xl font-bold">Capture the lead</h2>
                <p className="mt-2 text-slate-400">Collect founder details before the service selection stage.</p>
              </div>
              <div className="space-y-4">
                <input className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 text-white" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} />
                <input className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 text-white" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} />
                <button className="btn-primary w-full" onClick={() => setStep(2)}>Continue</button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h2 className="text-2xl font-bold">Choose service</h2>
              <div className="mt-5 grid gap-4 md:grid-cols-2">
                {services.map(s => (
                  <button key={s} onClick={() => setService(s)} className={`rounded-2xl border p-4 text-left ${service === s ? 'border-emerald-400 bg-emerald-500/10' : 'border-white/10 bg-slate-950'}`}>
                    {s}
                  </button>
                ))}
              </div>
              <button className="btn-primary mt-5" onClick={() => setStep(3)}>Continue</button>
            </div>
          )}

          {step === 3 && (
            <div>
              <h2 className="text-2xl font-bold">Bundle upsell</h2>
              <div className="mt-5 grid gap-4 md:grid-cols-3">
                {packages.map(p => (
                  <button key={p} onClick={() => setPack(p)} className={`rounded-2xl border p-4 text-left ${pack === p ? 'border-emerald-400 bg-emerald-500/10' : 'border-white/10 bg-slate-950'}`}>
                    {p}
                  </button>
                ))}
              </div>
              <button className="btn-primary mt-5" onClick={() => setStep(4)}>Continue</button>
            </div>
          )}

          {step === 4 && (
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h2 className="text-2xl font-bold">Checkout summary</h2>
                <div className="mt-4 space-y-3 rounded-2xl border border-white/10 bg-slate-950 p-4">
                  <div className="flex justify-between"><span className="text-slate-400">Lead</span><span>{name || 'Founder'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Email</span><span>{email || 'email@example.com'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Service</span><span>{service}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Bundle</span><span>{pack}</span></div>
                </div>
              </div>
              <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-5">
                <div className="text-sm text-emerald-300">Automation handoff</div>
                <div className="mt-2 text-3xl font-black">Lead captured and routed</div>
                <p className="mt-3 text-slate-200">This is the handoff point for payment, CRM tagging, email automation, and follow-up sequences.</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </Layout>
  );
}
