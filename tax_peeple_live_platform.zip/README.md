# Tax Peeple Live Platform

A deployable Next.js starter for:
- Marketing website
- SaaS dashboard frontend
- Lead-generation funnel

## Stack
- Next.js 14
- React
- Tailwind CSS

## Run locally
```bash
npm install
npm run dev
```

## Deploy
- Vercel for frontend
- Replace mock data with real API endpoints
